const { guard, res, ok, missing, timeout, fail } = require('./_shared');
const SYSTEM = 'Eres NEXUS, una IA multimodal: inteligente, analítica, precisa y cercana. Responde en el idioma del usuario. Si no tienes información suficiente, dilo claramente.';
exports.handler = async (event) => {
  const g = guard(event, 30); if (g) return g;
  const { messages = [], image } = JSON.parse(event.body || '{}');
  const msgs = messages.slice(-20).map((m) => ({ role: m.role, content: String(m.content).slice(0, 8000) }));
  const last = msgs[msgs.length - 1];
  if (!last) return res(400, 'Mensaje vacío');
  try {
    if (process.env.ANTHROPIC_API_KEY) {
      if (image) last.content = [{ type: 'image', source: { type: 'base64', media_type: image.type, data: image.data } }, { type: 'text', text: last.content }];
      const r = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST', signal: timeout(),
        headers: { 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
        body: JSON.stringify({ model: process.env.CHAT_MODEL || 'claude-sonnet-5-5', max_tokens: 1500, system: SYSTEM, messages: msgs }) });
      const d = await r.json(); if (!r.ok) return res(502, d.error?.message || 'Error del proveedor');
      return ok({ text: d.content.map((c) => c.text || '').join('') });
    }
    if (process.env.GEMINI_API_KEY) {
      const contents = msgs.map((m) => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] }));
      if (image) contents[contents.length - 1].parts.unshift({ inlineData: { mimeType: image.type, data: image.data } });
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${process.env.GEMINI_MODEL || 'gemini-2.5-flash'}:generateContent`, { method: 'POST', signal: timeout(),
        headers: { 'x-goog-api-key': process.env.GEMINI_API_KEY, 'content-type': 'application/json' },
        body: JSON.stringify({ systemInstruction: { parts: [{ text: SYSTEM }] }, contents }) });
      const d = await r.json(); if (!r.ok) return res(502, d.error?.message || 'Error del proveedor');
      return ok({ text: (d.candidates?.[0]?.content?.parts || []).map((p) => p.text || '').join('') || 'El modelo no devolvió respuesta.' });
    }
    if (process.env.OPENAI_API_KEY) {
      if (image) last.content = [{ type: 'image_url', image_url: { url: `data:${image.type};base64,${image.data}` } }, { type: 'text', text: last.content }];
      const r = await fetch('https://api.openai.com/v1/chat/completions', { method: 'POST', signal: timeout(),
        headers: { authorization: `Bearer ${process.env.OPENAI_API_KEY}`, 'content-type': 'application/json' },
        body: JSON.stringify({ model: process.env.OPENAI_CHAT_MODEL || 'gpt-4o-mini', max_tokens: 1500, messages: [{ role: 'system', content: SYSTEM }, ...msgs] }) });
      const d = await r.json(); if (!r.ok) return res(502, d.error?.message || 'Error del proveedor');
      return ok({ text: d.choices[0].message.content });
    }
    return missing('GEMINI_API_KEY (gratis), ANTHROPIC_API_KEY u OPENAI_API_KEY');
  } catch (e) { return fail(e); }
};
