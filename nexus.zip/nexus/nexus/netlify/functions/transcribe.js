const { guard, res, ok, missing, timeout, fail } = require('./_shared');
exports.handler = async (event) => {
  const g = guard(event, 10); if (g) return g;
  const { data, type, name } = JSON.parse(event.body || '{}');
  if (!data || !String(type).startsWith('audio/')) return res(400, 'Archivo de audio no válido');
  try {
    if (process.env.GEMINI_API_KEY) {
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${process.env.GEMINI_MODEL || 'gemini-2.5-flash'}:generateContent`, { method: 'POST', signal: timeout(),
        headers: { 'x-goog-api-key': process.env.GEMINI_API_KEY, 'content-type': 'application/json' },
        body: JSON.stringify({ contents: [{ parts: [{ inlineData: { mimeType: type, data } }, { text: 'Transcribe este audio literalmente, en su idioma original. Devuelve solo la transcripción.' }] }] }) });
      const d = await r.json(); if (!r.ok) return res(502, d.error?.message || 'Error transcribiendo');
      return ok({ text: (d.candidates?.[0]?.content?.parts || []).map((p) => p.text || '').join('') });
    }
    if (!process.env.OPENAI_API_KEY) return missing('GEMINI_API_KEY u OPENAI_API_KEY');
    const fd = new FormData();
    fd.append('model', 'whisper-1');
    fd.append('file', new Blob([Buffer.from(data, 'base64')], { type }), name || 'audio');
    const r = await fetch('https://api.openai.com/v1/audio/transcriptions', { method: 'POST', signal: timeout(), headers: { authorization: `Bearer ${process.env.OPENAI_API_KEY}` }, body: fd });
    const d = await r.json(); if (!r.ok) return res(502, d.error?.message || 'Error transcribiendo');
    return ok({ text: d.text });
  } catch (e) { return fail(e); }
};
