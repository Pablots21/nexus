const hits = new Map();
const res = (statusCode, error, data) => ({ statusCode, headers: { 'content-type': 'application/json' }, body: JSON.stringify(error ? { error } : data) });
exports.res = res;
exports.ok = (d) => res(200, null, d);
exports.missing = (v) => res(501, `Pendiente de configuración: falta ${v} en las variables de entorno de Netlify.`);
exports.timeout = (ms = 25000) => AbortSignal.timeout(ms);
exports.fail = (e) => res(504, e.name === 'TimeoutError' ? 'El proveedor tardó demasiado. Intenta de nuevo.' : 'No se pudo conectar con el proveedor.');
exports.guard = (event, max = 20) => {
  if (event.httpMethod !== 'POST') return res(405, 'Método no permitido');
  const k = process.env.NEXUS_ACCESS_KEY;
  if (k && event.headers['x-nexus-key'] !== k) return res(401, 'Clave de acceso incorrecta');
  if ((event.body || '').length > 6e6) return res(413, 'Archivo demasiado grande (máx. 4 MB)');
  const ip = event.headers['x-nf-client-connection-ip'] || 'local', now = Date.now();
  const a = (hits.get(ip) || []).filter((t) => now - t < 6e4);
  if (a.length >= max) return res(429, 'Demasiadas solicitudes. Espera un minuto.');
  a.push(now); hits.set(ip, a);
};
