const { guard, res, ok, missing, timeout, fail } = require('./_shared');
exports.handler = async (event) => {
  const g = guard(event, 10); if (g) return g;
  const { prompt } = JSON.parse(event.body || '{}');
  if (!prompt) return res(400, 'Describe la imagen que quieres');
  const p = String(prompt).slice(0, 3000);
  try {
    if (process.env.GEMINI_API_KEY) {
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${process.env.GEMINI_IMAGE_MODEL || 'gemini-2.5-flash-image'}:generateContent`, { method: 'POST', signal: timeout(),
        headers: { 'x-goog-api-key': process.env.GEMINI_API_KEY, 'content-type': 'application/json' },
        body: JSON.stringify({ contents: [{ parts: [{ text: p }] }] }) });
      const d = await r.json(); if (!r.ok) return res(502, d.error?.message || 'Error generando la imagen (puede requerir facturación en Google)');
      const part = (d.candidates?.[0]?.content?.parts || []).find((x) => x.inlineData);
      return part ? ok({ b64: part.inlineData.data }) : res(502, 'El modelo no devolvió imagen. Reformula la descripción.');
    }
    if (!process.env.OPENAI_API_KEY) return missing('GEMINI_API_KEY u OPENAI_API_KEY');
    const r = await fetch('https://api.openai.com/v1/images/generations', { method: 'POST', signal: timeout(),
      headers: { authorization: `Bearer ${process.env.OPENAI_API_KEY}`, 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'gpt-image-1', prompt: p, size: '1024x1024' }) });
    const d = await r.json(); if (!r.ok) return res(502, d.error?.message || 'Error generando la imagen');
    return ok({ b64: d.data[0].b64_json });
  } catch (e) { return fail(e); }
};
