// PENDIENTE: no hay proveedor de video conectado todavía.
// Para activarlo, agrega aquí la llamada a un proveedor (p. ej. Replicate, Runway o Luma) y su clave en las variables de entorno.
const { guard, ok } = require('./_shared');
exports.handler = async (event) => {
  const g = guard(event, 10); if (g) return g;
  return ok({ text: 'La generación de video aún no está configurada: falta conectar un proveedor de video en netlify/functions/video.js.' });
};
